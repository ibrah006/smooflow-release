#!/bin/bash

LOG_FILE="/tmp/plotiwa_update.log"

# Redirect ALL output (stdout + stderr) to log file
exec > >(tee -a "$LOG_FILE") 2>&1

echo "========== UPDATE START =========="
echo "Time: $(date)"

VERSION="$1"
UPDATE_DOWNLOADED_DIR="$2"

# The app was called smooflow.app before it became Plotiwa.app. Take whichever
# app the update contains, install it as Plotiwa.app, and remove the old name.
SRC="$(/usr/bin/find "$UPDATE_DOWNLOADED_DIR" -maxdepth 1 -name '*.app' -type d | head -n 1)"
APPS="${PLOTIWA_APPS_DIR:-/Applications}"  # overridable for testing only
DST="$APPS/Plotiwa.app"
OLD="$APPS/smooflow.app"

echo "New Version: $VERSION"
echo "Source: $SRC"
echo "Destination: $DST"

# Validate source
if [ -z "$SRC" ] || [ ! -d "$SRC" ]; then
  echo "❌ Error: no app found in $UPDATE_DOWNLOADED_DIR"
  exit 1
fi

echo "Waiting for app to close..."
sleep 5

echo "Removing old app..."
/bin/rm -rf "$DST" || echo "⚠️ Failed to remove existing app"
if [ -d "$OLD" ]; then
  /bin/rm -rf "$OLD" || echo "⚠️ Failed to remove $OLD"
fi

echo "Copying new app..."
/bin/cp -R "$SRC" "$DST" || {
  echo "❌ Copy failed"
  exit 1
}

echo "Removing quarantine..."
/usr/bin/xattr -dr com.apple.quarantine "$DST" || echo "⚠️ Quarantine removal failed"

echo "Launching app..."
/usr/bin/open "$DST" || echo "⚠️ Failed to open app"

echo "✅ Update complete at $(date)"
echo "========== UPDATE END =========="